'use strict';

const { vault } = require('../brain/api_vault.js');

const PLT_AFFINITY = { profit: 0.5, love: 0.3, tax: 0.2 };

async function skill_clawhub(input) {
    const missing = [];
    const v_CLAWHUB_TOKEN = vault.getKey('CLAWHUB_TOKEN'); if (!v_CLAWHUB_TOKEN) missing.push('CLAWHUB_TOKEN');
    if (missing.length > 0) {
        return { skill: 'clawhub', plt_affinity: PLT_AFFINITY, success: false, needs_key: true, missing_keys: missing, message: `Missing API keys: ${missing.join(', ')} — add to API Vault (src/data/api_vault.json) or set env vars`, timestamp: Date.now() };
    }
    const _CLAWHUB_TOKEN = vault.getKey('CLAWHUB_TOKEN');
    return { skill: 'clawhub', plt_affinity: PLT_AFFINITY, success: true, message: 'ClawHub skill ready — keys configured', keys_available: ['CLAWHUB_TOKEN'], timestamp: Date.now() };
}

module.exports = { skill_clawhub, PLT_AFFINITY };